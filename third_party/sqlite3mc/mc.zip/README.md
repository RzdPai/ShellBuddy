# Release notes

Release date: 2026-10-12

Version information:
  - SQLite3MC 2.6.1
  - SQLite 3.54.0

# SQLite3 Multiple Ciphers amalgamation

This archive contains the source code amalgamation of _SQLite3 Multiple
Ciphers_. The original, unmodified SQLite sources are not included
anymore, but can be downloaded - if needed - from

https://sqlite.org/2026/sqlite-amalgamation-3540000.zip

## Archive content

File name                | Description
:----------------------- | :----------
sqlite3mc_amalgamation.c | C source, SQLite3 Multiple Ciphers amalgamation
sqlite3mc_amalgamation.h | C header, SQLite3 Multiple Ciphers amalgamation
shell3mc_amalgamation.c  | C source of the SQLite shell, SQLite3 Multiple Ciphers amalgamation
sqlite3.h                | C header, original SQLite
sqlite3ext.h             | C header for extensions, original SQLite

## Support

If you have any comments or problems open an issue on the _SQLite3 Multiple Ciphers_ github page:
https://github.com/utelle/SQLite3MultipleCiphers/issues
